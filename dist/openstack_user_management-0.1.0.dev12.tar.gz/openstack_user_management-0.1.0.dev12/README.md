Setup development environment
=============================
Clone repository
$ git clone http://username@bitbucket.b3lab.org/scm/ba/openstack_user_management.git
$ cd sen

Create a virtual environment
$ virtualenv ./.venv

Switch to virtual environment
$ source ./.venv/bin/activate

Install requirements
$ pip install -r requirements.txt

If you are using PyCharm, set `Project Interpreter`
setting to the created virtual environment


Run tests
=========
Run style tests
$ tox -e pep8

Run unit tests
$ tox -e py27


Packaging Operations
=======================
1. Show pip operations in debug mode
    * $ export export DISTUTILS_DEBUG=1
2. Setup.py Help Commands
    * $ python setup.py --help-commands
3. Create a tar.gz file for distribution
    * $ python setup.py sdist
4. Install packaged file to a system
    * $ sudo pip install openstack_user_management.tar.gz
5. Uninstall openstack_user_management from system
    * $ sudo pip uninstall openstack_user_management
6. Build Wheel File
    * $ python setup.py bdist_wheel [--universal]
7. Create an RPM distribution file
    * $ python setup.py bdist_rpm
8. After installation with pip install command,
   Run the following command to start openstack_user_management/web/rest_server module.
    * $ openstack_user_managementrun

    Debian Packaging
    ---------------------
    Required Packages: stdeb, debhelper

    $ sudo apt-get install python-stdeb<br>
    $ pip install stdeb

    helper programs for debian/rules: (if not automatically installed)<br>
    $ sudo apt-get install debhelper

    #### Commands
    1. py2dsc, takes a .tar.gz source package and build a Debian source package from it
    2. py2dsc-deb takes a .tar.gz source package and build a Debian source package and then a .deb file from it

    * $ py2dsc openstack_user_management.tar.gz
    * $ py2dsc-deb openstack_user_management.tar.gz

    [Debian Reference](https://pypi.python.org/pypi/stdeb#py2dsc-deb-command-line-command)
